CREATE SCHEMA Flights;
GO
CREATE TABLE Flights.AIRPORT(
	Airport_code INT PRIMARY KEY,
	Name VARCHAR(50) NOT NULL,
	City VARCHAR(20) NOT NULL,
	State VARCHAR(20) NOT NULL
);
CREATE TABLE Flights.AIRPLANE_TYPE(
	Type_Name VARCHAR(20) PRIMARY KEY,
	Company VARCHAR(20) NOT NULL,
	Max_Num_Seats INT NOT NULL
);
CREATE TABLE Flights.CAN_LAND(
	Airport INT NOT NULL REFERENCES Flights.AIRPORT(Airport_code),
	Airplane_Type VARCHAR(20) NOT NULL REFERENCES Flights.AIRPLANE_TYPE(Type_Name),
	PRIMARY KEY (Airport, Airplane_Type)
);
CREATE TABLE Flights.AIRPLANE(
	ID INT PRIMARY KEY,
	Total_Num_Seats INT NOT NULL,
	Type VARCHAR(20) NOT NULL REFERENCES Flights.AIRPLANE_TYPE(Type_Name)
);
CREATE TABLE Flights.FLIGHT(
	Flight_Number INT PRIMARY KEY,
	Airline VARCHAR(20) NOT NULL,
	Weekdays INT NOT NULL
);
CREATE TABLE Flights.FARE(
	Code INT NOT NULL,
	Flight INT NOT NULL REFERENCES Flights.FLIGHT(Flight_Number),
	Amount INT NOT NULL,
	Restrictions VARCHAR(100) NOT NULL,
	PRIMARY KEY (Code, Flight)
);
CREATE TABLE Flights.FLIGHT_LEG(
	Leg_Number INT NOT NULL,
	Flight_Number INT NOT NULL REFERENCES Flights.FLIGHT(Flight_Number),
	Sch_Dep_Time TIME NOT NULL,
	Sch_Arrival_Time TIME NOT NULL,
	Dep_Airport INT NOT NULL REFERENCES Flights.AIRPORT(Airport_code),
	Arrival_Airport INT NOT NULL REFERENCES Flights.AIRPORT(Airport_code),
	PRIMARY KEY (Leg_Number, Flight_Number)
);
CREATE TABLE Flights.LEG_INSTANCE(
	Date DATE NOT NULL,
	Leg_Number INT NOT NULL,
	Flight_Number INT NOT NULL,
	Avail_Seats INT NOT NULL,
	Airplane INT NOT NULL REFERENCES Flights.AIRPLANE(ID),
	Dep_Time TIME NOT NULL,
	Arrival_Time TIME NOT NULL,
	Dep_Airport INT NOT NULL REFERENCES Flights.AIRPORT(Airport_code),
	Arrival_Airport INT NOT NULL REFERENCES Flights.AIRPORT(Airport_code),
	FOREIGN KEY (Leg_Number, Flight_Number) REFERENCES Flights.FLIGHT_LEG(Leg_Number, Flight_Number),
	PRIMARY KEY (Date, Leg_Number, Flight_Number)
);
CREATE TABLE Flights.SEAT(
	Seat_Number INT NOT NULL,
	Date DATE NOT NULL,
	Leg_Number INT NOT NULL,
	Flight_Number INT NOT NULL,
	Customer_Name VARCHAR(50) NOT NULL,
	Customer_Phone VARCHAR(50) NOT NULL,
	FOREIGN KEY (Date, Leg_Number, Flight_Number) REFERENCES Flights.LEG_INSTANCE(Date, Leg_Number, Flight_Number),
	PRIMARY KEY(Seat_Number, Date, Leg_Number, Flight_Number)
);